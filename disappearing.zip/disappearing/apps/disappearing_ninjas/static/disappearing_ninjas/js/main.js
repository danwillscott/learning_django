/**
 * Created by danielscott on 1/20/17.
 */
console.log('Main.js has been loaded waiting for next command')