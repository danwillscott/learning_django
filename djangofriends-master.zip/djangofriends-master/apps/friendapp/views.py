from django.shortcuts import render
from . import models

# Create your views here.

#
# def index(req):
#     users = models.Users.objects.all()
#     context = {'users': users}
#     return render(req, "friendapp/index.html", context)


def index(req):
    # users = models.Users.objects.all()  # TODO This was broken
    users = models.Users.objects.filter(last_name='Rodriguez')
    # users = models.Users.objects.exclude(last_name='Rodriguez')
    # users = models.Users.objects.filter(last_name='Rodriguez') | models.Users.objects.filter(first_name='Daniel')
    # users = models.Users.objects.filter(last_name='Rodriguez') | models.Users.objects.exclude(first_name='Madison')
    # users = models.Users.objects.filter(last_name='Rodriguez').exclude(first_name='Madison')
    # users = models.Users.objects.all().exclude(first_name='Daniel').exclude(first_name='Michael').exclude(last_name='Rodriguez')
    # users = models.Users.objects.get(id=4)
    # users = models.Users.objects.get(last_name='Rodriguez')  # This does not work! It will return all objects with this last name
    # users = models.Users.objects.get(id=10000)  # this returns an error because no id 10000
    # users = models.Users.objects.order_by('first_name')
    # users = models.Users.objects.order_by('-last_name')
    # users = models.Friendships.objects.all()
    # user_id = models.Friendships.objects.get(id=4)
    # users = models.Users.objects.filter(id=user_id.friend_id)

    # a_list = []
    # for friend in users:
    #     temp = models.Users.objects.get(id=friend.friend_id)  # THIS IS FUCKING NUTS WTF
    #     a_list.append(temp)
    # users = models.Friendships.objects.all().exclude(user_id=(4, 5, 6)).order_by('created_at')
    # a_list = [] # HEY THIS GIVES DOUBLES OF SOME PEOPLE NOT SURE HOW TO FIX!
    # for friend in users:
    #     temp = models.Users.objects.get(id=friend.friend_id)
    #     a_list.append(temp)
    # users = models.Users.objects.filter(id=users)


    # Add this line!
    # print (users.query)

    print (a_list)  # TODO find a better way to handle this
    # end of add
    context = {'users': a_list}
    return render(req, "friendapp/index.html", context)
